@extends('layouts.app')

@section('content')
<div class="container">
<h3>Edit Product</h3>
<form method="POST" action="/product/{{ $product -> id }}">
@csrf
<input type="hidden" name="_method" value="put">
  <div class="form-group">
    <label for="productName">Product Name</label>
    <input value="{{ $product->name }}" type="text" name="productName" class="form-control" id="productName" placeholder="Enter Product Name">
  </div>
  <div class="form-group">
    <label for="price">Price</label>
    <input value="{{ $product->price }}" type="text" name="price" class="form-control" id="price" placeholder="Enter Product Price">
  </div>
  <div class="form-group">
    <label for="quantity">Quantity</label>
    <input value="{{ $product->quantity }}" type="number" name="quantity" class="form-control" id="quantity" placeholder="Enter Product Quantity">
  </div>
  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>
@endsection
