@extends('layouts.app')

@section('content')
<div class="container">
<div class="mb-2 d-flex align-items-center justify-content-between">
<h3>Products</h3>
<a class="btn btn-success" href="{{ route('new-product') }}">Add New</a>
</div>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  @foreach ($product as $product)
    <tr>
      <th scope="row">{{ $product -> id }}</th>
      <td>{{ $product -> name }}</td>
      <td>{{ $product -> price }}</td>
      <td>{{ $product -> quantity }}</td>
      <td>
        <a href="/product/{{ $product-> id }}/edit" class="btn btn-primary btn-sm">Edit</a>
        <a onclick='ConfirmDelete({{  $product->id }})' class="btn btn-danger btn-sm" >Delete</a>
      </td>
    </tr>
@endforeach
  </tbody>
</table>
</div>
@endsection


@section('scripts')
  <script>
  function ConfirmDelete(id){
    if(confirm('Are you sure want to delete ?')){
        window.location.href = `/product/${id}/delete`;
    }
  }
  </script>
@endsection