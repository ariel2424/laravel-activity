<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Who Am I</title>
</head>
<body>
    haloo!
</body>
</html><?php /**PATH C:\laragon\www\laravel-activity\resources\views/activity.blade.php ENDPATH**/ ?>