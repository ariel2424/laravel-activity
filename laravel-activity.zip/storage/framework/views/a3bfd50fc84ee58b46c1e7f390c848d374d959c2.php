

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="mb-2 d-flex align-items-center justify-content-between">
<h3>Products</h3>
<a class="btn btn-success" href="<?php echo e(route('new-product')); ?>">Add New</a>
</div>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($product -> id); ?></th>
      <td><?php echo e($product -> name); ?></td>
      <td><?php echo e($product -> price); ?></td>
      <td><?php echo e($product -> quantity); ?></td>
      <td>
        <a href="/product/<?php echo e($product-> id); ?>/edit" class="btn btn-primary btn-sm">Edit</a>
        <a onclick='ConfirmDelete(<?php echo e($product->id); ?>)' class="btn btn-danger btn-sm" >Delete</a>
      </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script>
  function ConfirmDelete(id){
    if(confirm('Are you sure want to delete ?')){
        window.location.href = `/product/${id}/delete`;
    }
  }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-activity\resources\views/product.blade.php ENDPATH**/ ?>